export class NotifyDto {
  accountId: string;
  title: string;
  desc: string;
}
