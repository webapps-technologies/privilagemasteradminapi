export class CreateLicencePlanDto {}
