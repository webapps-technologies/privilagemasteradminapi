import { Injectable } from '@nestjs/common';
import { CreateLicencePlanDto } from './dto/create-licence-plan.dto';
import { UpdateLicencePlanDto } from './dto/update-licence-plan.dto';

@Injectable()
export class LicencePlanService {
}
