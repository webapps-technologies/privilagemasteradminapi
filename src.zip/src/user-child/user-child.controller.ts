import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { UserChildService } from './user-child.service';
import { CreateUserChildDto } from './dto/create-user-child.dto';
import { UpdateUserChildDto } from './dto/update-user-child.dto';

@Controller('user-child')
export class UserChildController {
  constructor(private readonly userChildService: UserChildService) {}

  @Post()
  create(@Body() createUserChildDto: CreateUserChildDto) {
    return this.userChildService.create(createUserChildDto);
  }

  @Get()
  findAll() {
    return this.userChildService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.userChildService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateUserChildDto: UpdateUserChildDto) {
    return this.userChildService.update(+id, updateUserChildDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userChildService.remove(+id);
  }
}
