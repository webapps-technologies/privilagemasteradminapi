import { Injectable } from '@nestjs/common';
import { CreateUserChildDto } from './dto/create-user-child.dto';
import { UpdateUserChildDto } from './dto/update-user-child.dto';

@Injectable()
export class UserChildService {
  create(createUserChildDto: CreateUserChildDto) {
    return 'This action adds a new userChild';
  }

  findAll() {
    return `This action returns all userChild`;
  }

  findOne(id: number) {
    return `This action returns a #${id} userChild`;
  }

  update(id: number, updateUserChildDto: UpdateUserChildDto) {
    return `This action updates a #${id} userChild`;
  }

  remove(id: number) {
    return `This action removes a #${id} userChild`;
  }
}
