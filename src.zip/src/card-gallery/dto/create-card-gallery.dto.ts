export class CreateCardGalleryDto {}
