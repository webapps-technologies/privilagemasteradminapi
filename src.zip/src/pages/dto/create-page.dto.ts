export class CreatePageDto {}
