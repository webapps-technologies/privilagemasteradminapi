export class CreateAdminDetailDto {}
