export class CreateUserPermissionDto {}
