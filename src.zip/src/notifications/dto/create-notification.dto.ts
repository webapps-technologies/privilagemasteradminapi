export class CreateNotificationDto {}
