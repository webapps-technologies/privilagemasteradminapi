import { MailerService } from '@nestjs-modules/mailer';
import { Controller, Get } from '@nestjs/common';

@Controller('node-mailer')
export class NodeMailerController {
  constructor() {}
}
