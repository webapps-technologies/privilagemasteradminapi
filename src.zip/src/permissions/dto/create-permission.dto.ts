export class CreatePermissionDto {}
