export class CreateLoginHistoryDto {}
